// Placeholder service worker for GitHub Pages mirror.
// This does NOT enable Firebase Cloud Messaging without your Firebase project config.
self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => { /* noop */ });
self.addEventListener('push', (e) => {
  // Avoid errors if site attempts to use push; show a generic notification.
  const data = (e && e.data && e.data.text && e.data.text()) || 'Push received';
  e.waitUntil(self.registration.showNotification('Site Mirror', { body: data }));
});
